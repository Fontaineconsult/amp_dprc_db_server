create view caption_student_courses as
  SELECT student.student_id, student.student_first_name, student.student_last_name, student.student_email, student.student_requests, student.captioning_active, student.transcripts_only, current_enrollement.subject_code, current_enrollement.course_number, current_enrollement.section_number, current_enrollement.class_title, current_enrollement.instructor_id, current_enrollement.instructor_name, current_enrollement.instructor_email FROM (student JOIN current_enrollement ON (((student.student_id)::text = (current_enrollement.student_id)::text)));

