create view current_enrollement as
  SELECT studentenrollement.course_reg_number, studentenrollement.student_id, rawcourselist.id, rawcourselist.subject_code, rawcourselist.course_number, rawcourselist.section_number, rawcourselist.class_title, rawcourselist.instructor_name, rawcourselist.instructor_email, rawcourselist.instructor_id FROM (studentenrollement JOIN rawcourselist ON (((studentenrollement.course_reg_number)::text = (rawcourselist.course_regestration_number)::text)));

